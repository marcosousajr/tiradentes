package prova1;

public enum Categoria {

	Scooter, Naked, Sport,
	Hatch, Sedan, SUV;
	
	
	}
