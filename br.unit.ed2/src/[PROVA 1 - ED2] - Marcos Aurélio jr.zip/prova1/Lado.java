package prova1;

public enum Lado {
	Esquerdo,
	Meio,
	Direito;
}
