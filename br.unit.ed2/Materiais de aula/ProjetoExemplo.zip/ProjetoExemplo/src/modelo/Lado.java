package modelo;

/**
 * 
 * 
 * 
 * @author Rafael Oliveira Vasconcelos
 */
public enum Lado {
  Esquerdo,
  Meio,
  Direito;
}
